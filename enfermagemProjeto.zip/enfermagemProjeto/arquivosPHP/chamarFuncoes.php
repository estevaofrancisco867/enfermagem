<?php
include "logarCadastrar_Funcoes.php";
include "conexaoBanco.php";
include "crud_funcoes.php";

// Variáveis usadas como parâmetro apenas pelas funções logar e cadastrar //
$email = $_POST["email"]?? null;                                                 //  
$senha = $_POST["senha"]?? null;                                                 //  
$tipo = $_POST["tipo"]?? null;                                                   //  
//////////////////////////////////////////////////////////////////////////


$nome  = $_POST["nome"] ; 
$bula  = $_POST["bula"]; 
$tipoRemedio  = $_POST["tipoRemedio"]; 
$publicoAlvo = $_POST["publicoAlvo"]; 
$precaucoes  = $_POST["precaucoes"]; 
$contraIndicacoes  = $_POST["contraIndicacoes"]; 
$composicao  = $_POST["composicao"]; 
$efeitos  = $_POST["efeitos"]; 


// Ação de login/cadastro
if (isset($_GET["acao"]) && $_GET["acao"] === "login") {
    logar($email, $senha, $conn);
}

// Ação de registro
if (isset($_GET["acao"]) && $_GET["acao"] === "cadastro") {
    cadastrar($email, $senha, $conn, $tipo);
}

if (isset($_GET["acao"]) && $_GET["acao"] === "adicionar") {
    adicionar($conn,$nome,$bula, $tipoRemedio, $publicoAlvo, $precaucoes, $contraIndicacoes,$composicao, $efeitos);
}

?>