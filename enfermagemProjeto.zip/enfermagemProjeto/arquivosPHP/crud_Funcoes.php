<?php
include "conexaoBanco.php";

// Função de registro
function adicionar($conn, $nome, $bula, $tipoRemedio, $publicoAlvo, $precaucoes, 
$contraIndicacoes, $composicao, $efeitos,$empresa, $cnpj, $cidade , $uf,$substancia  ,$substancia_tipo){
	
    $consultaSQL_3 = "SELECT ID_REMEDIO FROM REMEDIOS ORDER BY ID_REMEDIO DESC LIMIT 1";
    $resultado_3 = $conn->query($consultaSQL_3);
    if (!$resultado_3) {
        die("Erro ao buscar último ID: " . $conn->error);
    }
    $linha = $resultado_3->fetch_assoc();

    // Evita erro caso a tabela esteja vazia
    $ultimoID = isset($linha['ID_REMEDIO']) ? $linha['ID_REMEDIO'] + 1 : 1;


     $consultaSQL_5 = $conn->prepare("INSERT INTO remedios_db.SUBSTANCIAS 
    (ID_SUBSTANCIAS , NOME, TIPO) 
    VALUES (?, ?, ?)");

    if (!$consultaSQL_5) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_5->bind_param("iss", $ultimoID,$substancia, $substancia_tipo);
    $resultado_5 = $consultaSQL_5->execute();

    
    $consultaSQL_2 = $conn->prepare("INSERT INTO remedios_db.PRESCRICOES 
    (ID_PRESCRICAO, PUBLICO_ALVO, PRECAUCOES, CONTRA_INDICACOES, COMPOSICAO, EFEITOS) 
    VALUES (?, ?, ?, ?, ?, ?)");

    if (!$consultaSQL_2) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_2->bind_param("isssss",$ultimoID, $publicoAlvo, $precaucoes, $contraIndicacoes, $composicao, $efeitos);
    $resultado_2 = $consultaSQL_2->execute();

    // Inserir remédio
    $consultaSQL = $conn->prepare("INSERT INTO remedios_db.REMEDIOS 
    (id_remedio, nome, bula, tipo, ID_PRESCRICAO, ID_SUBSTANCIAS) 
    VALUES (?, ?, ?, ?, ?, ?)");
    if (!$consultaSQL) {
    die("Erro no prepare remedios: " . $conn->error);
}

    $consultaSQL->bind_param("isssii",$ultimoID, $nome, $bula, $tipoRemedio, $ultimoID, $ultimoID);
    $resultado = $consultaSQL->execute();

///////////////////////////////////////////////
      $consultaSQL_6 = $conn->prepare("INSERT INTO remedios_db.CIDADES 
    (ID_CIDADE, NOME, UF) 
    VALUES (?, ?, ?)");

    if (!$consultaSQL_6) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_6->bind_param("iss", $ultimoID, $cidade , $uf);
    $resultado_6 = $consultaSQL_6->execute();   

/////////////////////////

     $consultaSQL_4 = $conn->prepare("INSERT INTO remedios_db.EMPRESAS 
    (ID_EMPRESA, NOME, CNPJ,ID_CIDADE ) 
    VALUES (?, ?, ?, ?)");

    if (!$consultaSQL_4) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_4->bind_param("issi", $ultimoID, $empresa, $cnpj, $ultimoID);
    $resultado_4 = $consultaSQL_4->execute();
////////////////////////////////////////
    

$consultaSQL_7 = $conn->prepare("INSERT INTO remedios_db.EMPRESAS_REMEDIOS 
    (ID_EMPRESAS, ID_REMEDIOS) 
    VALUES (?, ?)");

    if (!$consultaSQL_7) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_7->bind_param("ii", $ultimoID,$ultimoID);
    $resultado_7 = $consultaSQL_7->execute();

    // Verificação corrigida
    if ($resultado == true && $resultado_2 === true && $resultado_6 === true 
    && $resultado_4 === true && $resultado_5 === true && $resultado_7 === true  ) {
        header("Location: paginaDosRemedios_AcessoProfessor.php");
        exit;
    }

    $consultaSQL_2->close();
    $consultaSQL->close();
    $consultaSQL_6->close();
    $consultaSQL_4->close();
    $consultaSQL_5->close();
    $consultaSQL_7->close();
}

function editar($conn,$id,$nome_paraAlterar,$bula_paraAlterar, $tipoRemedio_paraAlterar, 
    $publicoAlvo_paraAlterar, $precaucoes_paraAlterar, 
    $contraIndicacoes_paraAlterar,$composicao_paraAlterar, 
    $efeitos_paraAlterar,$empresa_paraAlterar,$cnpj_paraAlterar, $cidade_paraAlterar,
    $uf_paraAlterar, $substancia_paraAlterar,$substancia_tipo_paraAlterar ){

$ultimoID=$id;


$consultaSQL_2 = $conn->prepare("
    UPDATE remedios_db.PRESCRICOES 
    SET PUBLICO_ALVO = ?, 
        PRECAUCOES = ?, 
        CONTRA_INDICACOES = ?, 
        COMPOSICAO = ?, 
        EFEITOS = ?
    WHERE ID_PRESCRICAO = ?
");

if (!$consultaSQL_2) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

$consultaSQL_2->bind_param(
    "sssssi",
    $publicoAlvo_paraAlterar,
    $precaucoes_paraAlterar,
    $contraIndicacoes_paraAlterar,
    $composicao_paraAlterar,
    $efeitos_paraAlterar,
    $ultimoID
);

$resultado_2 = $consultaSQL_2->execute();


// Atualizar remédio
$consultaSQL = $conn->prepare("
    UPDATE remedios_db.REMEDIOS 
    SET nome = ?, 
        bula = ?, 
        tipo = ?
    WHERE ID_REMEDIO = ? 
");

if (!$consultaSQL) {
    die("Erro no prepare remedios: " . $conn->error);
}

$consultaSQL->bind_param(
    "sssi",
    $nome_paraAlterar,
    $bula_paraAlterar,
    $tipoRemedio_paraAlterar,
    $ultimoID
);

$resultado = $consultaSQL->execute();


$consultaSQL_3 = $conn->prepare("
    UPDATE remedios_db.SUBSTANCIAS 
    SET NOME = ?, 
        TIPO = ?
    WHERE ID_SUBSTANCIAS = ?
");



$consultaSQL_3->bind_param(
    "ssi",
    $substancia_paraAlterar,
    $substancia_tipo_paraAlterar,
    $ultimoID
);


$resultado_3 = $consultaSQL_3->execute();

$consultaSQL_4 = $conn->prepare("
    UPDATE remedios_db.EMPRESAS 
    SET NOME = ?, 
        CNPJ = ?
    WHERE ID_EMPRESA = ?
");

$consultaSQL_4->bind_param(
    "ssi",
    $empresa_paraAlterar,
    $cnpj_paraAlterar,
    $ultimoID
);

$resultado_4 = $consultaSQL_4->execute();

$consultaSQL_5 = $conn->prepare("
    UPDATE remedios_db.CIDADES 
    SET NOME = ?, 
        UF = ?
    WHERE ID_CIDADE = ?
");

$consultaSQL_5->bind_param(
    "ssi",
    $cidade_paraAlterar,
    $uf_paraAlterar,
    $ultimoID
);

$resultado_5 = $consultaSQL_5->execute();

// Verificação
if ($resultado === true && $resultado_2 === true && $resultado_3 === true && $resultado_4 === true
&& $resultado_5 === true ) {
    header("Location: paginaDosRemedios_AcessoProfessor.php");
    exit;
}


$consultaSQL_2->close();
$consultaSQL->close();
$consultaSQL_3->close();
$consultaSQL_4->close();
$consultaSQL_5->close();
}


function excluir($conn,$id){
$ultimoID=$id;    

$consultaSQL_EMPRESAS_REMEDIOS= $conn-> prepare("DELETE FROM remedios_db.EMPRESAS_REMEDIOS  WHERE ID_EMPRESAS =? AND ID_REMEDIOS =? ;");
$consultaSQL_EMPRESAS_REMEDIOS->bind_param("ii", $ultimoID, $ultimoID);
$resultado_6 = $consultaSQL_EMPRESAS_REMEDIOS->execute();

$consultaSQL_remedios = $conn->prepare("DELETE FROM remedios_db.REMEDIOS WHERE ID_REMEDIO = ?;");
$consultaSQL_remedios->bind_param("i", $ultimoID);
$resultado_1 = $consultaSQL_remedios->execute();

$consultaSQL_empresas = $conn-> prepare("DELETE FROM remedios_db.EMPRESAS WHERE ID_EMPRESA =?;");
$consultaSQL_empresas->bind_param("i", $ultimoID);
$resultado_4 = $consultaSQL_empresas->execute();

$consultaSQL_prescricoes = $conn-> prepare("DELETE FROM remedios_db.PRESCRICOES  WHERE ID_PRESCRICAO =?;");
$consultaSQL_prescricoes->bind_param("i", $ultimoID);
$resultado_2 = $consultaSQL_prescricoes->execute();

$consultaSQL_substancias = $conn-> prepare("DELETE FROM remedios_db.SUBSTANCIAS  WHERE ID_SUBSTANCIAS =?;");
$consultaSQL_substancias->bind_param("i", $ultimoID);
$resultado_3 = $consultaSQL_substancias->execute();

$consultaSQL_cidades= $conn-> prepare("DELETE FROM remedios_db.CIDADES  WHERE ID_CIDADE =?;");
$consultaSQL_cidades->bind_param("i", $ultimoID);
$resultado_5 = $consultaSQL_cidades->execute();


if ($resultado_1 === true && $resultado_2 === true && $resultado_3 === true
&& $resultado_4 === true && $resultado_5 === true && $resultado_6 === true) {
header("Location: paginaDosRemedios_AcessoProfessor.php");
exit;
}
}
?>