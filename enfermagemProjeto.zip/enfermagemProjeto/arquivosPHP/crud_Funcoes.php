<?php
include "conexaoBanco.php";

// Função de registro
function adicionar($conn, $nome, $bula, $tipoRemedio, $publicoAlvo, $precaucoes, $contraIndicacoes, $composicao, $efeitos){

    $consultaSQL_3 = "SELECT ID_DESCRICAO FROM DESCRICAO ORDER BY ID_DESCRICAO DESC LIMIT 1";
    $resultado_3 = $conn->query($consultaSQL_3);
    if (!$resultado_3) {
        die("Erro ao buscar último ID: " . $conn->error);
    }
    $linha = $resultado_3->fetch_assoc();

    // Evita erro caso a tabela esteja vazia
    $ultimoID = isset($linha['ID_DESCRICAO']) ? $linha['ID_DESCRICAO'] + 1 : 1;

    
    $consultaSQL_2 = $conn->prepare("INSERT INTO remedios_db.descricao 
    (ID_DESCRICAO, PUBLICO_ALVO, PRECAUCOES, CONTRA_INDICACOES, COMPOSICAO, EFEITOS) 
    VALUES (?, ?, ?, ?, ?, ?)");

    if (!$consultaSQL_2) {
    die("Erro no prepare descricao: " . $conn->error);
}

    $consultaSQL_2->bind_param("isssss", $ultimoID, $publicoAlvo, $precaucoes, $contraIndicacoes, $composicao, $efeitos);
    $resultado_2 = $consultaSQL_2->execute();

    // Inserir remédio
    $consultaSQL = $conn->prepare("INSERT INTO remedios_db.REMEDIOS 
    (nome, bula, tipo, ID_DESCRICAO) 
    VALUES (?, ?, ?, ?)");
    if (!$consultaSQL) {
    die("Erro no prepare remedios: " . $conn->error);
}

    $consultaSQL->bind_param("sssi", $nome, $bula, $tipoRemedio, $ultimoID);
    $resultado = $consultaSQL->execute();

    // Verificação corrigida
    if ($resultado == true && $resultado_2 === true) {
        header("Location: paginaDosRemedios.php");
        exit;
    }

    
    $consultaSQL_2->close();
    $consultaSQL->close();
}
?>