<?php
include "conexaoBanco.php";

// Função de registro
function adicionar($conn, $nome, $bula, $tipoRemedio, $publicoAlvo, $precaucoes, $contraIndicacoes, $composicao, $efeitos){
	
    $consultaSQL_3 = "SELECT ID_PRESCRICAO FROM PRESCRICOES ORDER BY ID_PRESCRICAO DESC LIMIT 1";
    $resultado_3 = $conn->query($consultaSQL_3);
    if (!$resultado_3) {
        die("Erro ao buscar último ID: " . $conn->error);
    }
    $linha = $resultado_3->fetch_assoc();

    // Evita erro caso a tabela esteja vazia
    $ultimoID = isset($linha['ID_PRESCRICAO']) ? $linha['ID_PRESCRICAO'] + 1 : 1;

    
    $consultaSQL_2 = $conn->prepare("INSERT INTO remedios_db.PRESCRICOES 
    (ID_PRESCRICAO, PUBLICO_ALVO, PRECAUCOES, CONTRA_INDICACOES, COMPOSICAO, EFEITOS) 
    VALUES (?, ?, ?, ?, ?, ?)");

    if (!$consultaSQL_2) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

    $consultaSQL_2->bind_param("isssss", $ultimoID, $publicoAlvo, $precaucoes, $contraIndicacoes, $composicao, $efeitos);
    $resultado_2 = $consultaSQL_2->execute();

    // Inserir remédio
    $consultaSQL = $conn->prepare("INSERT INTO remedios_db.REMEDIOS 
    (nome, bula, tipo, ID_PRESCRICAO) 
    VALUES (?, ?, ?, ?)");
    if (!$consultaSQL) {
    die("Erro no prepare remedios: " . $conn->error);
}

    $consultaSQL->bind_param("sssi", $nome, $bula, $tipoRemedio, $ultimoID);
    $resultado = $consultaSQL->execute();

    // Verificação corrigida
    if ($resultado == true && $resultado_2 === true) {
        header("Location: paginaDosRemedios_AcessoProfessor.php");
        exit;
    }

    
    $consultaSQL_2->close();
    $consultaSQL->close();
}



function editar($conn,$id,$nome_paraAlterar,$bula_paraAlterar, $tipoRemedio_paraAlterar, $publicoAlvo_paraAlterar, $precaucoes_paraAlterar, 
$contraIndicacoes_paraAlterar,
$composicao_paraAlterar, $efeitos_paraAlterar){

$ultimoID=$id;


$consultaSQL_2 = $conn->prepare("
    UPDATE remedios_db.PRESCRICOES 
    SET PUBLICO_ALVO = ?, 
        PRECAUCOES = ?, 
        CONTRA_INDICACOES = ?, 
        COMPOSICAO = ?, 
        EFEITOS = ?
    WHERE ID_PRESCRICAO = ?
");

if (!$consultaSQL_2) {
    die("Erro no prepare PRESCRICOES: " . $conn->error);
}

$consultaSQL_2->bind_param(
    "sssssi",
    $publicoAlvo_paraAlterar,
    $precaucoes_paraAlterar,
    $contraIndicacoes_paraAlterar,
    $composicao_paraAlterar,
    $efeitos_paraAlterar,
    $ultimoID
);

$resultado_2 = $consultaSQL_2->execute();


// Atualizar remédio
$consultaSQL = $conn->prepare("
    UPDATE remedios_db.REMEDIOS 
    SET nome = ?, 
        bula = ?, 
        tipo = ?
    WHERE ID_PRESCRICAO = ? 
");

if (!$consultaSQL) {
    die("Erro no prepare remedios: " . $conn->error);
}

$consultaSQL->bind_param(
    "sssi",
    $nome_paraAlterar,
    $bula_paraAlterar,
    $tipoRemedio_paraAlterar,
    $ultimoID
);

$resultado = $consultaSQL->execute();

// Verificação
if ($resultado === true && $resultado_2 === true) {
    header("Location: paginaDosRemedios_AcessoProfessor.php");
    exit;
}

$consultaSQL_2->close();
$consultaSQL->close();
}

function excluir($conn,$id){
$ultimoID=$id;    
$consultaSQL_1 = $conn->prepare("DELETE FROM remedios_db.REMEDIOS WHERE ID_PRESCRICAO = ?;");
$consultaSQL_1->bind_param("i", $ultimoID);
$resultado_1 = $consultaSQL_1->execute();
$consultaSQL_2 = $conn-> prepare("DELETE FROM remedios_db.PRESCRICOES  WHERE ID_PRESCRICAO =?;");
$consultaSQL_2->bind_param("i", $ultimoID);
$resultado_2 = $consultaSQL_2->execute();

if ($resultado_1 === true && $resultado_2 === true) {
header("Location: paginaDosRemedios_AcessoProfessor.php");
exit;
}
}
?>