<?php
include "conexaoBanco.php";

// Função de registro
function adicionar($nome,$bula, $tipo, $publicoAlvo, $precaucoes, $contraIndicacoes,$composicao, $efeitos){
    $inserindoRegistros = $conn->prepare("INSERT INTO  remedios_db.REMEDIOS,(nome, bula, tipo) 
    VALUES (?, ?, ?)");
    $inserindoRegistros->bind_param("sss", $nome, $bula, $tipo);

    $resultado = inserindoRegistros->execute();

  
    if ($resultado === true) {
        header("Location: paginaDosRemedios.php");
        exit;
    } 
}
?>