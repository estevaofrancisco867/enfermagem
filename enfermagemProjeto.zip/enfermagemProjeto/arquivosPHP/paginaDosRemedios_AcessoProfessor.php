<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabela de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h3>Lista de Produtos</h3>
    <a href="adicionar.php" class="btn btn-success mb-3">Adicionar Remédio</a>
    <a href = "cadastrarProfessor.php" class="btn btn-primary mb-3">Cadastrar Mais Professores </a>
    <!-- Campo de pesquisa simples -->
    <input class="form-control mb-3" id="filtroInput" type="text" placeholder="Pesquisar por nome...">

    <?php if (isset($_GET['sucesso'])) {
    echo "<div class='alert alert-success'>
            Remédio salvo com sucesso!
          </div>";
        }
        if (isset($_GET['editado'])) {  
    echo "<div class='alert alert-success'>Remédio atualizado com sucesso!</div>";
        }   

        if (isset($_GET['excluido'])) { 
    echo "<div class='alert alert-success'>Remédio excluído com sucesso!</div>";
        }   
    ?>
    <table class="table table-bordered table-striped" id="tabelaProdutos"
    >
        <thead class="table-dark">
            <tr>
                 <th>NOME</th>
                 <th>BULA</th>  
                 <th>TIPO</th>  
                 <th>PRECAUÇÕES</th>
                 <th>CONTRA INDICAÇÕES</th>
                 <th>COMPOSIÇÃO</th>
                 <th>EFEITOS</th>
                 <th>VALIDADE</th>
                 <th>AÇÕES</th>
            </tr>
        </thead>

        <tbody>
            <?php
            include("conexaoBanco.php"); 

            $sql = "SELECT * FROM REMEDIOS, PRESCRICOES WHERE REMEDIOS.ID_PRESCRICAO = PRESCRICOES.ID_PRESCRICAO";
            $result = $conn->query($sql);

            $sql_outras = "SELECT TARJAS.NOME AS 'NOME_TARJA' , SUBSTANCIAS.NOME AS 'NOME_SUBSTANCIA',
            SUBSTANCIAS.TIPO AS 'TIPO_SUBSTANCIA',  
    PUBLICO_ALVO.NOME AS 'PUBLICO_ALVO_NOME',
    EMPRESAS.NOME AS 'NOME_EMPRESA', 
    CNPJ, 
    CIDADES.NOME AS 'NOME_CIDADE', 
    UF   

    FROM CIDADES, EMPRESAS, SUBSTANCIAS, EMPRESAS_REMEDIOS, REMEDIOS, TARJAS, PUBLICO_ALVO,SUBSTANCIAS_REMEDIOS,
    REMEDIOS_PUBLICO_ALVO 

    WHERE REMEDIOS.ID_TARJAS = TARJAS.ID_TARJA  AND
    SUBSTANCIAS.ID_SUBSTANCIA = SUBSTANCIAS_REMEDIOS.ID_SUBSTANCIA 
    AND SUBSTANCIAS_REMEDIOS.ID_REMEDIO = SUBSTANCIAS_REMEDIOS.ID_SUBSTANCIA
    AND PUBLICO_ALVO.ID_PUBLICO_ALVO = REMEDIOS_PUBLICO_ALVO.ID_PUBLICO_ALVO
    AND REMEDIOS_PUBLICO_ALVO.ID_REMEDIO = REMEDIOS_PUBLICO_ALVO.ID_PUBLICO_ALVO
    AND EMPRESAS.ID_EMPRESA = EMPRESAS_REMEDIOS.ID_EMPRESA 
    AND EMPRESAS_REMEDIOS.ID_REMEDIO = EMPRESAS_REMEDIOS.ID_EMPRESA
    AND EMPRESAS.ID_CIDADE = CIDADES.ID_CIDADE";

    $result_outras = $conn->query($sql_outras);

            if ($result->num_rows > 0) {
                while (($row = $result->fetch_assoc()) && ($row_outras = $result_outras->fetch_assoc())) {
                    echo "<tr>";
                    echo "<td>". $row['NOME'] ."</td>";
                    echo "<td><a href='". $row['BULA'] ."' target='_blank'>Ver Bula</a></td>";
                    echo "<td>". $row['TIPO'] ."</td>";
                    echo "<td>". $row['RESTRICAO'] ."</td>";
                    echo "<td>". $row['CONTRA_INDICACOES'] ."</td>";
                    echo "<td>". $row['COMPOSICAO'] ."</td>";
                    echo "<td>". $row['EFEITOS'] ."</td>";
                    echo "<td>". $row['VALIDADE'] ."</td>";
                    echo "<td>
                    <a href ='verMais.php?id=" . $row['ID_REMEDIO'] .   
"&nome_tarja_verMais=" . $row_outras['NOME_TARJA'] .                                     
"&nome_substancia_verMais=" . $row_outras['NOME_SUBSTANCIA'] . 
"&tipoSubstancia_verMais=" . $row_outras['TIPO_SUBSTANCIA'] .
"&nome_publicoAlvo_verMais=" . $row_outras['PUBLICO_ALVO_NOME'] . 
"&nomeEmpresa_verMais=" . $row_outras['NOME_EMPRESA'] .
"&cnpj_verMais=" . $row_outras['CNPJ'] .
"&nomeCidade_verMais=" . $row_outras['NOME_CIDADE'] .
"&uf_verMais=" . $row_outras['UF'] . "' 
style='margin-right: 10px;'  
class='link-offset-2 link-underline link-underline-opacity-100'>
                    Ver Mais
                    </a>

                    
                            <a href='editar.php?id=" . $row['ID_REMEDIO'] . 
	"&nome_paraAlterar=" . $row['NOME'] . 
	"&bula_paraAlterar=" . $row['BULA'] . 
	"&tipo_paraAlterar=" . $row['TIPO'] .  
	"&RESTRICAO_paraAlterar=" . $row['RESTRICAO'] . 
	"&contraIndicacoes_paraAlterar=" . $row['CONTRA_INDICACOES'] . 
	"&composicao_paraAlterar=" . $row['COMPOSICAO'] . 
    "&efeitos_paraAlterar=" . $row['EFEITOS'] . 
    "&validade_paraAlterar=" . $row['VALIDADE'] .
    "&nome_tarja_paraAlterar=" . $row_outras['NOME_TARJA'] .
	"&substancia_paraAlterar=" . $row_outras['NOME_SUBSTANCIA'] . 
	"&substancia_tipo_paraAlterar=" . $row_outras['TIPO_SUBSTANCIA'] .
    "&publicoAlvo_paraAlterar=" . $row['PUBLICO_ALVO_NOME'] .
    "&empresa_paraAlterar=" . $row_outras['NOME_EMPRESA'] .
    "&cnpj_paraAlterar=" . $row_outras['CNPJ'] .
    "&cidade_paraAlterar=" .$row_outras['NOME_CIDADE'] .
    "&uf_paraAlterar=" . $row_outras['UF'] . "
    ' class='btn btn-warning'>Editar</a>
                            
                            <a href='excluir.php?id=" . $row['ID_REMEDIO'] . "' style='margin-left:20px; margin-right: 5px;' class='btn btn-danger'>
                            Excluir
                            </a>
                        </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>Nenhum registro encontrado</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</div>
                
<script>
     document.getElementById('filtroInput').addEventListener('keyup', function() {
    let filtro = this.value.toLowerCase();
    let linhas = document.querySelectorAll('#tabelaProdutos tbody tr');

    for (let i = 0; i < linhas.length; i++) {
        let nome = linhas[i].cells[0].textContent.toLowerCase();
        linhas[i].style.display = nome.includes(filtro) ? '' : 'none';
    }
});
</script>

</body>
</html>


