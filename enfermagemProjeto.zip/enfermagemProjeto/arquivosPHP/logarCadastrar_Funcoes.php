<?php
include "conexaoBanco.php";
// Função de validação/login
function logar($email, $senha, $conn){
    $consultaSQL = $conn->prepare("SELECT * FROM remedios_db.usuarios WHERE email = ? AND senha = ?");
    $consultaSQL->bind_param("ss", $email, $senha);
    $consultaSQL->execute();
    $resultado = $consultaSQL->get_result();

    if ($resultado->num_rows > 0){
        header("Location: /enfermagemProjeto/arquivosPHP/paginaDosRemedios.php");
        exit;
    } else {
    echo "<script>
        alert('Login não encontrado. Tente outro email/senha.');
        window.location.href = '/enfermagemProjeto/paginasHTML/login.html';
    </script>";
    exit;
}
}

// Função de registro
function cadastrar($email, $senha, $conn, $tipo){
    $consultaSQL = $conn->prepare("INSERT INTO remedios_db.usuarios(email, senha, tipo) VALUES (?, ?, ?)");
    $consultaSQL->bind_param("sss", $email, $senha, $tipo);

    $resultado = $consultaSQL->execute();

  
    if ($resultado === true) {
        header("Location: /enfermagemProjeto/paginasHTML/login.html");
        exit;
    } else {
        echo "<script>alert('Não foi possível. Tente novamente');</script>";
        exit;
    }
}
?>