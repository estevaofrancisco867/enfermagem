<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<title>Adicionar Remédio</title>
</head>
<body class="bg-light">

<div class="container mt-4">
<a href="paginaDosRemedios_AcessoProfessor.php" 
class="btn btn-danger  position-absolute top-0 start-0 m-3" style ="font-size: 20px ;">
X
</a>
<form class="border border-success rounded p-3 mx-auto" style="max-width: 700px; margin-top: 100px;" 
action="chamarFuncoes.php?acao=adicionar" method="post">
<div class="text-center mb-4">
    <h1 class="fw-bold text-success" style = "font-size: 35px;">
        Cadastro de Medicamento
    </h1>
    <p class="text-muted small mb-0">
        Preencha as informações abaixo para registrar um novo medicamento
    </p>
    <hr class="w-25 mx-auto border-success opacity-75">
</div><div class="row">

<div class="col-md-6 mb-2">
<label class="form-label small">Nome</label>
<input name="nome" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Bula</label>
<input name="bula" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Tipo</label>
<input name="tipoRemedio" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>


<div class="col-md-6 mb-2">
<label class="form-label small">Precauções</label>
<input name="RESTRICAO" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Contraindicações</label>
<input name="contraIndicacoes" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Composição</label>
<input name="composicao" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Efeitos</label>
<input name="efeitos" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>


<div class="col-md-6 mb-2">
<label class="form-label small">Validade</label>
<input name="validade" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Nome da tarja</label>
<input name="tarja" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Substância presente no remédio</label>
<input name="substancia" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Tipo de substância</label>
<input name="substancia_tipo" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Público-Alvo</label>
<input name="publicoAlvo" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>


<div class="col-md-6 mb-2">
<label class="form-label small">Nome da empresa fabricante</label>
<input name="empresa" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">CNPJ da empresa fabricante</label>
<input name="cnpj" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Cidade em que reside a empresa</label>
<input name="cidade" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">UF</label>
<input name="uf" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>


</div>

<button class="btn btn-success btn-sm w-100 mt-2">Salvar</button>

</form>
</div>

<script src="js/formValidation.js"></script>
</body>
</html>