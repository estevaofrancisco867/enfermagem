<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<title>Form</title>
</head>
<body class="bg-light">

<div class="container mt-4">
<form class="border border-success rounded p-3 mx-auto" style="max-width: 700px;" 
action="chamarFuncoes.php?acao=adicionar" method="post">

<div class="row">

<div class="col-md-6 mb-2">
<label class="form-label small">Nome</label>
<input name="nome" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Bula</label>
<input name="bula" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Tipo</label>
<input name="tipo" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>


<div class="col-md-6 mb-2">
<label class="form-label small">Público-Alvo</label>
<input name="publicoAlvo" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Precauções</label>
<input name="precaucoes" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Contraindicações</label>
<input name="contraIndicacoes" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Composição</label>
<input name="composicao" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Efeitos</label>
<input name="efeitos" class="form-control form-control-sm">
<p class="text-danger small mb-0"></p>
</div>

</div>

<button class="btn btn-success btn-sm w-100 mt-2">Salvar</button>

</form>
</div>

<script src="js/formValidation.js"></script>
</body>
</html>