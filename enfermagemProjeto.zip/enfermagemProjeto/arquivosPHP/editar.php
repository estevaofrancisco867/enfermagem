<?php
$id = $_GET['id'];
$url = "http://localhost:8080/remedios/api/remedios?id=$id";

$response = file_get_contents($url);
$r = json_decode($response, true);
?>

<form action="atualizar.php" method="post">

    <input type="hidden" name="id" value="<?= $r['id'] ?>">

    <input type="text" name="nome" value="<?= $r['nome'] ?>" required>
    <input type="text" name="bula" value="<?= $r['bula'] ?>" required>

    <input type="text" name="publicoAlvo" value="<?= $r['descricao']['publicoAlvo'] ?>" required>
    <input type="text" name="precaucoes" value="<?= $r['descricao']['precaucoes'] ?>" required>
    <input type="text" name="contraIndicacoes" value="<?= $r['descricao']['contraIndicacoes'] ?>" required>
    <input type="text" name="composicao" value="<?= $r['descricao']['composicao'] ?>">
    <input type="text" name="efeitos" value="<?= $r['descricao']['efeitos'] ?>" required>

    <button type="submit">Atualizar</button>

</form>