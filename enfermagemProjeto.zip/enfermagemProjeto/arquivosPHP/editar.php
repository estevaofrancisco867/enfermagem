<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<title>Editar Medicamento</title>
</head>
<body class="bg-light">

<div class="container mt-4">

<form class="border border-warning rounded p-3 mx-auto" 
style="max-width: 700px; margin-top: 100px;" 
action="chamarFuncoes.php?acao=editar&id=<?php echo $_GET['id']; ?>" 
method="post">

<a href="paginaDosRemedios_AcessoProfessor.php" 
class="btn btn-danger  position-absolute top-0 start-0 m-3" style ="font-size: 20px ;">
X
</a>

<div class="text-center mb-4">
    <h1 class="fw-bold text-warning" style="font-size: 35px;">
        Editar Medicamento
    </h1>

    <p class="text-muted small mb-0">
        Altere as informações do medicamento abaixo
    </p>

    <hr class="w-25 mx-auto border-warning opacity-75">
</div>

<div class="row">

<div class="col-md-6 mb-2">
<label class="form-label small">Nome</label>
<input 
name="nome_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['nome']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Bula</label>
<input 
name="bula_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['bula']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Tipo</label>
<input 
name="tipoRemedio_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['tipo']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Público-Alvo</label>
<input 
name="publicoAlvo_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['publicoAlvo']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Precauções</label>
<input 
name="precaucoes_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['precaucoes']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Contraindicações</label>
<input 
name="contraIndicacoes_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['contraIndicacoes']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Composição</label>
<input 
name="composicao_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['composicao']; ?>">
<p class="text-danger small mb-0"></p>
</div>

<div class="col-md-6 mb-2">
<label class="form-label small">Efeitos</label>
<input 
name="efeitos_paraAlterar" 
class="form-control form-control-sm"
value="<?php echo $_GET['efeitos']; ?>">
<p class="text-danger small mb-0"></p>
</div>

</div>

<button class="btn btn-warning btn-sm w-100 mt-2" style="color: white;">
<strong>Alterar</strong>
</button>

</form>
</div>

<script src="js/formValidation.js"></script>
</body>
</html>