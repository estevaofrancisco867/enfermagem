<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Tabela de Produtos</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">

<div class="container mt-4">

    <a href="paginaDosRemedios_AcessoProfessor.php"
       class="btn btn-danger position-absolute top-0 start-0 m-3"
       style="font-size: 20px;">
        X
    </a>

    <h3>Lista de Produtos</h3>

    <div class="card mb-3 border-0 shadow-sm">
        <div class="card-body">

            <div class="row g-3">

                <div class="col-md-6">
                    <label class="form-label text-muted">Substância</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['nome_substancia_verMais']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label text-muted">Tipo</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['tipoSubstancia_verMais']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label text-muted">Empresa</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['nomeEmpresa_verMais']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label text-muted">CNPJ</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['cnpj_verMais']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label text-muted">Cidade</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['nomeCidade_verMais']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label text-muted">UF</label>
                    <input class="form-control bg-light"
                           readonly
                           value="<?php echo $_GET['uf_verMais']; ?>">
                </div>

            </div>

        </div>
    </div>

</div>

</body>
</html>