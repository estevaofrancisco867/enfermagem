<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabela de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

<a href="paginaDosRemedios_AcessoProfessor.php" 
class="btn btn-danger  position-absolute top-0 start-0 m-3" style ="font-size: 20px ;">
X
</a>

    <h3>Lista de Produtos</h3>

    <?php
    include("conexaoBanco.php"); 

    $sql = "SELECT SUBSTANCIAS.NOME AS 'NOME_SUBSTANCIA', 
    SUBSTANCIAS.TIPO, 
    EMPRESAS.NOME AS 'NOME_EMPRESA', 
    CNPJ, 
    CIDADES.NOME AS 'NOME_CIDADE', 
    UF   

    FROM CIDADES, EMPRESAS, SUBSTANCIAS, EMPRESAS_REMEDIOS, REMEDIOS 

    WHERE REMEDIOS.ID_SUBSTANCIAS = SUBSTANCIAS.ID_SUBSTANCIAS 
    AND EMPRESAS.ID_EMPRESA = EMPRESAS_REMEDIOS.ID_EMPRESAS 
    AND REMEDIOS.ID_REMEDIO = EMPRESAS_REMEDIOS.ID_REMEDIOS
    AND EMPRESAS.ID_CIDADE = CIDADES.ID_CIDADE";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        while ($row = $result->fetch_assoc()) {

            echo "<div class='card mb-3 border-0 shadow-sm'>";

            echo "<div class='card-body'>";

            echo "<div class='row g-3'>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>Substância</label>
                    <input class='form-control bg-light' readonly value='".$row['NOME_SUBSTANCIA']."'>
                  </div>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>Tipo</label>
                    <input class='form-control bg-light' readonly value='".$row['TIPO']."'>
                  </div>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>Empresa</label>
                    <input class='form-control bg-light' readonly value='".$row['NOME_EMPRESA']."'>
                  </div>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>CNPJ</label>
                    <input class='form-control bg-light' readonly value='".$row['CNPJ']."'>
                  </div>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>Cidade</label>
                    <input class='form-control bg-light' readonly value='".$row['NOME_CIDADE']."'>
                  </div>";

            echo "<div class='col-md-6'>
                    <label class='form-label text-muted'>UF</label>
                    <input class='form-control bg-light' readonly value='".$row['UF']."'>
                  </div>";

            echo "</div>";

            echo "</div>";
            echo "</div>";
        }

    } else {
        echo "<div class='alert alert-warning'>Nenhum registro encontrado</div>";
    }

    $conn->close();
    ?>

</div>

</body>
</html>