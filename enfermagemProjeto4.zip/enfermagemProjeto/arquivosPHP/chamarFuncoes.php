<?php
include "logarCadastrar_Funcoes.php";
include "conexaoBanco.php";
include "crud_funcoes.php";

// Variáveis usadas como parâmetro apenas pelas funções logar e cadastrar 
$email = $_POST["email"]?? null;                                                  
$senha = $_POST['senha']??  null;                                                  
$tipo = $_POST["tipo"]?? null;                                                   


$nome  = $_POST["nome"]?? null ; 
$bula  = $_POST["bula"]?? null; 
$tipoRemedio  = $_POST["tipoRemedio"]?? null; 
$publicoAlvo = $_POST["publicoAlvo"]?? null; 
$precaucoes  = $_POST["precaucoes"]?? null; 
$contraIndicacoes  = $_POST["contraIndicacoes"]?? null; 
$composicao  = $_POST["composicao"]?? null; 
$efeitos  = $_POST["efeitos"]?? null; 

$id = $_GET['id'] ?? null;

$nome_paraAlterar  = $_POST["nome_paraAlterar"] ?? null;
$bula_paraAlterar  = $_POST["bula_paraAlterar"] ?? null;
$tipoRemedio_paraAlterar  = $_POST["tipoRemedio_paraAlterar"] ?? null;
$publicoAlvo_paraAlterar = $_POST["publicoAlvo_paraAlterar"] ?? null;
$precaucoes_paraAlterar  = $_POST["precaucoes_paraAlterar"] ?? null;
$contraIndicacoes_paraAlterar  = $_POST["contraIndicacoes_paraAlterar"] ?? null;
$composicao_paraAlterar  = $_POST["composicao_paraAlterar"] ?? null;
$efeitos_paraAlterar  = $_POST["efeitos_paraAlterar"] ?? null; 


// Ação de login/cadastro
if (isset($_GET["acao"]) && $_GET["acao"] === "login") {
    logar($email, $senha, $conn);
}

// Ação de registro
if (isset($_GET["acao"]) && $_GET["acao"] === "cadastro") {
    cadastrar($email, $senha, $conn, $tipo);
}

// Ação de adicionar mais remédios
if (isset($_GET["acao"]) && $_GET["acao"] === "adicionar") {
    adicionar($conn,$nome,$bula, $tipoRemedio, $publicoAlvo, $precaucoes, $contraIndicacoes,$composicao, $efeitos);
}
if (isset($_GET["acao"]) && $_GET["acao"] === "editar") {
    editar($conn,$id,$nome_paraAlterar,$bula_paraAlterar, $tipoRemedio_paraAlterar, $publicoAlvo_paraAlterar, $precaucoes_paraAlterar, $contraIndicacoes_paraAlterar,$composicao_paraAlterar, $efeitos_paraAlterar);
}

?>